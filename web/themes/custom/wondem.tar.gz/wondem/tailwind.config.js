module.exports = {
  content: [
    "./templates/**/*.twig",
    "./src/**/*.js"
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};
