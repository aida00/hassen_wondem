import 'alpinejs';
import './frontpage.css';
