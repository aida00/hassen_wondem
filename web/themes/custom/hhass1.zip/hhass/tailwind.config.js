module.exports = {
  content: ["./templates/**/*.html.twig", "./src/**/*.{js,html}"],
  theme: {
    extend: {}
  },
  plugins: []
};

