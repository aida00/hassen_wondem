<?php

namespace Drupal\wondem_application_form\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Provides the Application Form.
 */
class ApplicationForm extends FormBase {

  public function getFormId() {
    return 'wondem_application_form';
  }

  public function buildForm(array $form, FormStateInterface $form_state) {
    $form['full_name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Full Name'),
      '#required' => TRUE,
    ];

    $form['email'] = [
      '#type' => 'email',
      '#title' => $this->t('Email'),
      '#required' => TRUE,
      '#attributes' => ['placeholder' => 'you@example.com'],
    ];

    $form['phone'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Phone No'),
    ];

    $form['source'] = [
      '#type' => 'radios',
      '#title' => $this->t('How did you hear about us?'),
      '#options' => [
        'recruitment_site' => $this->t('Recruitment Site'),
        'referral' => $this->t('Referral'),
        'other' => $this->t('Other (please specify)'),
      ],
    ];

    $form['employment_status'] = [
      '#type' => 'textfield',
      '#title' => $this->t('What is your current employment status?'),
    ];

    $form['equipment'] = [
      '#type' => 'radios',
      '#title' => $this->t('Do you have a reliable PC and internet connection?'),
      '#options' => ['yes' => $this->t('Yes'), 'no' => $this->t('No')],
    ];

    $form['experience_online'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Do you have online work/education experience?'),
    ];

    $form['availability'] = [
      '#type' => 'textarea',
      '#title' => $this->t('How much time per day can you allocate? When are you available?'),
    ];

    $form['experience_content'] = [
      '#type' => 'textarea',
      '#title' => $this->t('What is your experience in content writing? Please share samples or links.'),
    ];

    $form['team_experience'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Describe a time you worked with a team to resolve an IT issue.'),
    ];

    $form['proficiency_writing'] = [
      '#type' => 'textfield',
      '#title' => $this->t('How do you describe your proficiency in content writing?'),
    ];

    $form['proficiency_media'] = [
      '#type' => 'textfield',
      '#title' => $this->t('How do you describe your proficiency in images & video editing?'),
    ];

    $form['proficiency_tools'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Proficiency with version control, CMS (Drupal, WordPress), Linux?'),
    ];

    $form['education_experience'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Relevant education, work experience, or hobbies related to digital content?'),
    ];

    $form['salary_expectation'] = [
      '#type' => 'textfield',
      '#title' => $this->t('What is your salary expectation?'),
    ];

    $form['job_obstacles'] = [
      '#type' => 'textarea',
      '#title' => $this->t('What do you think will be an obstacle to your job, or what do you hate in a job?'),
    ];

    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Submit Application'),
      '#button_type' => 'primary',
    ];

    return $form;
  }

  public function submitForm(array &$form, FormStateInterface $form_state) {
    $values = $form_state->getValues();

    // Store everything into the 'data' column safely.
    \Drupal::database()->insert('wondem_applications')
      ->fields([
        'full_name' => $values['full_name'],
        'email' => $values['email'],
        'phone' => $values['phone'],
        'data' => serialize($values),
        'created' => \Drupal::time()->getRequestTime(),
      ])
      ->execute();

    \Drupal::messenger()->addMessage($this->t('Application submitted successfully!'));
  }
}
